Командная строка должна иметь вид (как и сказано в заданий):
./aes -e -k FILE1 -iv FILE2 -i FILE3 -o FILE4
./aes -d -k FILE1 -iv FILE2 -i FILE3 -o FILE4
либо
./aes -e -k FILE1 -i FILE2 -o FILE3
./aes -d -k FILE1 -i FILE2 -o FILE3

Также, поддерживаются полные аргументы (-encrypt, -decrypt, -key, -input, -output)

При других порядках вызова выбрасывается ошибка с подсказкой

